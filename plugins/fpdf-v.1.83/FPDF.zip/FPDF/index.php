<?php
require('fpdf183/fpdf.php');

$name = "Saim Sanan";
$fname = "Amjad Ali";
$cnic = "2312413435235";
$project = "Scholership-Turkefgghghy";
$projectId = "Scholershghcghip-1";
$image1 = "photo1.jpg";
$image2 = "sign.png";

// Table
$rollno = "112233123456";
$postname  = "Assistant Revenue Supdt";
$reporting = "19-8-2021 10:00 am";
$time = "10:30 am";
$testcenter = "ASRC";
$phone = "41342352345346";


class PDF extends FPDF
{

// Page header
function Header()
{
    // Logo
    $this->Image('logo.png',20,12,45);
    // Arial bold 15
    $this->SetFont('Arial','B',12);
    // Move to the right
    $this->Cell(80);
    // Title
    $this->Cell(60,10,'Universal Testing Services',0,0,'C');
    // Line break
    $this->Ln();
    // Arial bold 15
    $this->SetFont('Arial','',8);
    // Move to the right
    $this->Cell(65);
    // Text
    $this->SetTextColor(0, 0, 0);
    $this->Cell(34,5,'Phone: 051-111-258-369',0,0,"C");
    // Text
    $this->SetTextColor(0, 0, 0);
    $this->Cell(10,5,'Email:',0,0,"C");
    // Text
    $this->SetTextColor(0, 0, 255);
    $this->Cell(22,5,'info@uts.com.pk',0,0,"C");
    // Text
    $this->SetTextColor(0, 0, 0);
    $this->Cell(14,5,'Website:',0,0,"C");
    // Text
    $this->SetTextColor(0, 0, 255);
    $this->Cell(21,5,'www.uts.com.pk',0,0,"C");
    // Line break
    $this->Ln();
    // Line
    $this->SetDrawColor(0,0,0);
    $this->Line(20,30,190,30);
    // Line break
    $this->Ln();
}

// Page footer
function Footer()
{
    // // Position at 1.5 cm from bottom
    // $this->SetY(-15);
    // // Arial italic 8
    // $this->SetFont('Arial','I',8);
    // // Page number
    // $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}

// Instanciation of inherited class
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
// Line Break
$pdf->Ln();
// Image
$pdf->Image($image1,167,50,22,25);
$pdf->Ln();
// Image
$pdf->Image($image2,165,203,20,15);
// Font
$pdf->SetFont('Times','B',11);
// Empty Cell
$pdf->Cell(80);
// Roll no Heading
$pdf->Cell(30,6,'Roll No Slip',0,0,'C');
// Line Break
$pdf->Ln();
// Empty Cell
$pdf->Cell(65);
// Project
$pdf->Cell(60,5,$project."(".$projectId.")",0,0,'C');
// Line Break
$pdf->Ln();
$pdf->Ln();
// Font
$pdf->SetFont('Times','',9);
// Empty Cell
$pdf->Cell(9);
// CNIC
$pdf->Cell(13,5,'CNIC # :  ',0,0);
// Font
$pdf->SetFont('Times','B',9);
$pdf->Cell(30,5,$cnic,0,1);
// Empty Cell
$pdf->Cell(9);
// Font
$pdf->SetFont('Times','',9);
// Name
$pdf->Cell(10,5,'Name :  ',0,0);
// Font
$pdf->SetFont('Times','B',9);
$pdf->Cell(30,5,$name,0,1);
// Empty Cell
$pdf->Cell(9);
// Font
$pdf->SetFont('Times','',9);
// Father Name
$pdf->Cell(32,5,'Father/Guardian Name :  ',0,0);
// Font
$pdf->SetFont('Times','B',9);
$pdf->Cell(30,5,$fname,0,1);
// line Break
$pdf->Ln();
// line Break
$pdf->Ln();
// line Break
$pdf->Ln();
// line Break
$pdf->Ln();
// Table Font
$pdf->SetFont('Times','',8);
// Empty Cell
$pdf->Cell(9);
// Roll No
$pdf->Cell(25,7,'Roll No',1,0,'C');
// Post Name
$pdf->Cell(55,7,'Post Name',1,0,'C');
// Reporting date and Time
$pdf->Cell(30,7,'Reporting Date & Time',1,0,'C');
// Test Start Time
$pdf->Cell(20,7,'Test Start Time',1,0,'C');
// Test Center
$pdf->Cell(40,7,'Test Center',1,0,'C');
// line Break
$pdf->Ln();
// Empty Cell
$pdf->Cell(9);
// Roll No
$pdf->Cell(25,7,$rollno,1,0,'C');
// Post Name
$pdf->Cell(55,7,$postname,1,0,'C');
// Reporting date and Time
$pdf->Cell(30,7,$reporting,1,0,'C');
// Test Start Time
$pdf->Cell(20,7,$time,1,0,'C');
// Test Center
$pdf->Cell(40,7,$testcenter,1,0,'C');
// line Break
$pdf->Ln();
// line Break
$pdf->Ln();
// Font
$pdf->SetFont('Times','B',12);
// Empty Cell
$pdf->Cell(8);
// Instructions Heading
$pdf->Cell(25,5,'Instructions:',0,0,'C');
// line Break
$pdf->Ln(7);
// Instructions Body
// Font
$pdf->SetFont('Times','',10);
// Empty Cell
$pdf->Cell(8);
// 1
$pdf->MultiCell(170,5,'1. You are required to bring this Roll No Slip along with your original Identity Card for identification. No other identification documents like Passport, Driving License and Original Degrees are acceptable for identification, only original CNIC is acceptable with Roll No Slip.',0,'J');
// Empty Cell
$pdf->Cell(8);
// 2
$pdf->MultiCell(170,5,'2. You are also required to bring a Clipboard and ball pen/Marker (Black or Blue) with you. Clipboard should be clean without any writing. No paper for rough work is allowed. No paper for rough work is allowed.',0,'J');
// Empty Cell
$pdf->Cell(8);
// 3
$pdf->MultiCell(170,5,'3. Mobile Phone/Calculator or any other electronic device and wearable is not allowed. Please leave it outside the test center.',0,'J');
// Empty Cell
$pdf->Cell(8);
// 4
$pdf->MultiCell(170,5,'4. Center Management is not responsible for keeping student\'s belongings/valuables. No ladies hand bags are allowed in the center.',0,'J');
// Empty Cell
$pdf->Cell(8);
// 5
$pdf->MultiCell(170,5,'5. Any kind of weapon is strictly prohibited in the Examination Hall.',0,'J');
// Empty Cell
$pdf->Cell(8);
// 6
$pdf->MultiCell(170,5,'6. This is a provisional test subject to verification of your original documents, any discrepancy found later at any stage you will be disqualified.',0,'J');
// Empty Cell
$pdf->Cell(8);
// 7
$pdf->MultiCell(170,5,'7. Candidate is not allowed to enter in test center without mask',0,'J');
// Empty Cell
$pdf->Cell(8);
// 8
$pdf->Cell(43,5,'8. Keep visiting UTS website',0,0);
// Color
$pdf->SetTextColor(0, 0, 255);
// Link
$pdf->Cell(25,5,'www.uts.com.pk',0,0);
// Color
$pdf->SetTextColor(0, 0, 0);
// Text
$pdf->Cell(55,5,'for further information and test result',0,0);
// Line Break
$pdf->Ln(30);
// Font
$pdf->SetFont('Times','B',10);
// Empty Cell
$pdf->Cell(8);
// To
$pdf->Cell(8,5,'To,',0,0);
// Line Break
$pdf->Ln();
// Empty Cell
$pdf->Cell(8);
// Font
$pdf->SetFont('Times','B',9);
// Name
$pdf->Cell(11,5,'Name: '.$name.'  Guardian/Father Name: '.$fname,0,0);
// Line Break
$pdf->Ln();
// Empty Cell
$pdf->Cell(8);
// CNIC and Mobile
$pdf->Cell(11,5,'CNIC #: '.$cnic.'  Mobile #: '.$phone,0,0);
// Empty Cell
$pdf->Cell(130);
// To
$pdf->Cell(30,5,'Manager Operation',0,0);
$file_name = $name.".pdf";
$pdf->Output('D',$file_name);
?>